## smfucker

基于SM.SM图床的命令行小工具。

### 安装教程

```shell
pip install smfucker
```

### 使用方法

使用-h参数，查看所有命令。

```sh
C:\Users\hp>smfucker -h
usage: smfucker [-h] [-f FILE] [--history] [-d DATE] [-n NAME] [--upload UPLOAD] [--delete DELETE] [-l] [--user] [-v]

optional arguments:
  -h, --help            show this help message and exit
  -f FILE, --file FILE  Point to a md file
  --history             look all history
  -d DATE, --date DATE  search by date
  -n NAME, --name NAME  search by name
  --upload UPLOAD       upload by file path
  --delete DELETE       delete by hash
  -l, --login           login
  --user                get user profile
  -v, --version
```



#### 生成修改后的md文件

将md中的所有本地图片都上传到图床中，然后生成新的md文件。

#### 查看user信息

#### 查看所有上传历史

#### 根据名称和日期进行查找



